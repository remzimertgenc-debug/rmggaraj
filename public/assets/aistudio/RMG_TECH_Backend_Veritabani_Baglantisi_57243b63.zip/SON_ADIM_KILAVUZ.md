# RMG TECH - Veritabanı (Backend) Bağlantısı

Bu paket, uygulamanızın arka planını (backend) eski `userListings.json` dosyasından koparıp tamamen yeni kurduğumuz SQLite veritabanına bağlar. 

## Nasıl Yüklenir?
1. ZIP dosyasının içindeki **`server.ts`** dosyasını ve **`server`** klasörünü projenin ana dizinine sürükleyip bırakın (Eskilerinin üzerine yazdırılsın mı sorusuna 'Evet' deyin).
2. Terminalinizde sunucu çalışıyorsa (`npm run dev`) onu CTRL+C (veya CMD+C) ile durdurun.
3. Terminale tekrar `npm run dev` yazarak sunucuyu yeniden başlatın.

Artık siteniz üzerinden eklediğiniz tüm ilanlar ve fiyatlar doğrudan veritabanına yazılacak ve grafiklere yansımaya başlayacaktır. (Not: Eklediğiniz ilk ilanda grafiğin oluşması için en az 1 veri noktası gereklidir, test için bir ürüne birkaç farklı ilan fiyatı ekleyebilirsiniz).
