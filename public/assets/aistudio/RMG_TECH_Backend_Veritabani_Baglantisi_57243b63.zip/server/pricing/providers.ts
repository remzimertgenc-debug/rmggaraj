import { PrismaClient } from '@prisma/client';
import {
  CASE_DB,
  CPU_COOLER_DB,
  CPU_DB,
  GPU_DB,
  MOTHERBOARD_DB,
  PSU_DB,
  RAM_DB,
  SSD_DB,
} from '../../shared/hardwareCatalog.ts';
import type {
  MarketplaceListing,
  MarketplacePlatform,
  PartCategoryKey,
  PartPricingInfo,
  PriceSourceType,
  PricingCatalogResponse,
  ProductConditionGrade,
} from '../../src/types/pc.ts';
import { REFERENCE_RATES } from './referenceRates.ts';
import { analyzeMarketplaceListings, buildZeroVsUsedComparison } from './stats.ts';

const prisma = new PrismaClient();

interface AllPartMeta {
  id: string;
  model: string;
  brand: string;
  category: PartCategoryKey;
}

const ALL_PARTS: AllPartMeta[] = [
  ...CPU_DB.map((p) => ({ id: p.id, model: p.model, brand: p.brand, category: 'cpu' as const })),
  ...GPU_DB.map((p) => ({ id: p.id, model: p.model, brand: p.brand, category: 'gpu' as const })),
  ...MOTHERBOARD_DB.map((p) => ({
    id: p.id,
    model: p.model,
    brand: p.brand,
    category: 'motherboard' as const,
  })),
  ...RAM_DB.map((p) => ({ id: p.id, model: p.model, brand: p.brand, category: 'ram' as const })),
  ...SSD_DB.map((p) => ({ id: p.id, model: p.model, brand: p.brand, category: 'ssd' as const })),
  ...PSU_DB.map((p) => ({ id: p.id, model: p.model, brand: p.brand, category: 'psu' as const })),
  ...CASE_DB.map((p) => ({
    id: p.id,
    model: p.model,
    brand: p.brand,
    category: 'pcCase' as const,
  })),
  ...CPU_COOLER_DB.map((p) => ({
    id: p.id,
    model: p.model,
    brand: p.brand,
    category: 'cooler' as const,
  })),
];

export interface NewListingInput {
  partId: string;
  productName?: string;
  brandModel?: string;
  listingPriceTry: number;
  platform: MarketplacePlatform;
  listingUrl: string;
  listingDate: string;
  conditionGrade: ProductConditionGrade;
  isNew: boolean;
}

export async function addUserMarketplaceListing(input: NewListingInput): Promise<MarketplaceListing> {
  const meta = ALL_PARTS.find((p) => p.id === input.partId);
  if (!meta) {
    throw new Error('Geçersiz bileşen kimliği seçildi.');
  }

  // Önce ürün (Product) tablosunda donanım var mı bak, yoksa ekle (Upsert)
  await prisma.product.upsert({
    where: { id: meta.id },
    update: {},
    create: {
      id: meta.id,
      category: meta.category,
      brand: meta.brand,
      modelName: meta.model
    }
  });

  // Yeni ilanı (Listing) veritabanına ekle
  const record = await prisma.listing.create({
    data: {
      productId: meta.id,
      storeName: input.platform,
      url: input.listingUrl,
      currentPrice: input.listingPriceTry,
      isNew: input.isNew,
    }
  });

  // Fiyat geçmişi için (PriceLog) anlık fiyatı kütüğe işle
  await prisma.priceLog.create({
    data: {
      listingId: record.id,
      price: record.currentPrice
    }
  });

  return {
    id: record.id,
    partId: record.productId,
    productName: input.productName?.trim() || meta.model,
    brandModel: input.brandModel?.trim() || `${meta.brand} ${meta.model}`,
    listingPriceTry: record.currentPrice,
    platform: record.storeName as MarketplacePlatform,
    listingUrl: record.url,
    listingDate: record.updatedAt.toISOString().slice(0, 10),
    conditionGrade: input.conditionGrade,
    isNew: record.isNew,
    lastCheckedAt: record.updatedAt.toISOString(),
  };
}

export async function deleteUserMarketplaceListing(id: string): Promise<boolean> {
  try {
    // Önce bağlı fiyat geçmişlerini sil
    await prisma.priceLog.deleteMany({ where: { listingId: id } });
    // Sonra ilanı sil
    await prisma.listing.delete({ where: { id } });
    return true;
  } catch (error) {
    return false;
  }
}

async function fetchFromAuthorizedApi(): Promise<{
  configured: boolean;
  listings: MarketplaceListing[];
  statusMessage: string;
}> {
  const baseUrl = process.env.PRICE_API_BASE_URL?.trim();
  const apiKey = process.env.PRICE_API_KEY?.trim();

  if (!baseUrl || !apiKey) {
    return {
      configured: false,
      listings: [],
      statusMessage:
        'Harici yetkili pazar yeri API bağlantısı yapılandırılmadı. Gerçek ilan verisi için aşağıdan ilan kaydı ekleyebilirsiniz; ilan girilmeyen bileşenlerde yalnızca referans bütçe tahmini gösterilir.',
    };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);

    const response = await fetch(`${baseUrl.replace(/\/$/, '')}/listings`, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      return {
        configured: true,
        listings: [],
        statusMessage: `Yetkili fiyat API yanıt vermedi (${response.status}). Kullanıcı ilanları ve referans tahminleri kullanılıyor.`,
      };
    }

    const payload = (await response.json()) as { listings?: MarketplaceListing[] };
    const apiListings = Array.isArray(payload.listings) ? payload.listings : [];

    return {
      configured: true,
      listings: apiListings,
      statusMessage: `Yetkili pazar yeri API bağlantısı aktif (${apiListings.length} ilan senkronize edildi).`,
    };
  } catch {
    return {
      configured: true,
      listings: [],
      statusMessage:
        'Yetkili fiyat API sunucusuna şu anda ulaşılamıyor. Gerçek ilan yerine referans tahminleri ve kayıtlı kullanıcı ilanları gösteriliyor.',
    };
  }
}

export async function getPricingCatalog(): Promise<PricingCatalogResponse> {
  const apiResult = await fetchFromAuthorizedApi();
  
  // VERİTABANINDAN (SQLite) İLANLARI ÇEK
  const dbListingsRaw = await prisma.listing.findMany();
  const inMemoryListings: MarketplaceListing[] = dbListingsRaw.map(l => {
     const meta = ALL_PARTS.find(p => p.id === l.productId);
     return {
        id: l.id,
        partId: l.productId,
        productName: meta?.model || 'Bilinmeyen',
        brandModel: `${meta?.brand} ${meta?.model}`,
        listingPriceTry: l.currentPrice,
        platform: l.storeName as MarketplacePlatform,
        listingUrl: l.url,
        listingDate: l.updatedAt.toISOString().slice(0, 10),
        conditionGrade: l.isNew ? 'Sıfır / Kapalı Kutu' : 'İyi',
        isNew: l.isNew,
        lastCheckedAt: l.updatedAt.toISOString(),
     }
  });

  const combinedRawListings = [...apiResult.listings, ...inMemoryListings];
  const partsPricing: Record<string, PartPricingInfo> = {};
  const processedAllListings: MarketplaceListing[] = [];

  for (const part of ALL_PARTS) {
    const ref = REFERENCE_RATES[part.id];
    const partRawListings = combinedRawListings.filter((l) => l.partId === part.id);

    const newRaw = partRawListings.filter((l) => l.isNew);
    const usedRaw = partRawListings.filter((l) => !l.isNew);

    const newAnalysis = analyzeMarketplaceListings(
      newRaw,
      ref?.estimatedNewTry ?? null
    );
    const usedAnalysis = analyzeMarketplaceListings(
      usedRaw,
      ref?.estimatedUsedTry ?? null
    );

    processedAllListings.push(
      ...newAnalysis.processedListings,
      ...usedAnalysis.processedListings
    );

    let newPriceTry: number | null = ref?.estimatedNewTry ?? null;
    let newSourceType: PriceSourceType =
      newPriceTry !== null ? 'estimated_reference' : 'unavailable';
    let newSourceLabel =
      newPriceTry === 0
        ? 'Dahili / Kutu İçi (Ek Maliyet Yok)'
        : 'Gerçek ilan yok — Referans bütçe tahmini';

    if (newAnalysis.stats) {
      newPriceTry = newAnalysis.stats.medianPriceTry;
      newSourceType = apiResult.listings.some((l) => l.partId === part.id && l.isNew)
        ? 'authorized_api'
        : 'user_listings';
      newSourceLabel = `${newAnalysis.stats.sources.join(' / ')} (${
        newAnalysis.stats.listingCount
      } ilan medyanı)`;
    }

    let usedPriceTry: number | null = ref?.estimatedUsedTry ?? null;
    let usedSourceType: PriceSourceType =
      usedPriceTry !== null ? 'estimated_reference' : 'unavailable';
    let usedSourceLabel =
      usedPriceTry === 0
        ? 'Dahili / Kutu İçi (Ek Maliyet Yok)'
        : 'Gerçek ilan yok — Referans ikinci el tahmini';

    if (usedAnalysis.stats) {
      usedPriceTry = usedAnalysis.stats.medianPriceTry;
      usedSourceType = apiResult.listings.some((l) => l.partId === part.id && !l.isNew)
        ? 'authorized_api'
        : 'user_listings';
      usedSourceLabel = `${usedAnalysis.stats.sources.join(' / ')} (${
        usedAnalysis.stats.listingCount
      } ilan medyanı)`;
    }

    const lastCheckedAt =
      usedAnalysis.stats?.lastCheckedAt ??
      newAnalysis.stats?.lastCheckedAt ??
      null;

    partsPricing[part.id] = {
      partId: part.id,
      newPriceTry,
      usedPriceTry,
      newStats: newAnalysis.stats,
      usedStats: usedAnalysis.stats,
      newSourceType,
      usedSourceType,
      newSourceLabel,
      usedSourceLabel,
      lastCheckedAt,
      comparison: buildZeroVsUsedComparison(
        part.category,
        newPriceTry,
        usedPriceTry,
        newSourceLabel,
        usedSourceLabel
      ),
    };
  }

  return {
    providerStatus: {
      authorizedApiConfigured: apiResult.configured,
      providerMessage: apiResult.statusMessage,
      lastSyncedAt: new Date().toISOString(),
    },
    partsPricing,
    listings: processedAllListings,
  };
}
