import {
  CASE_DB,
  CPU_COOLER_DB,
  CPU_DB,
  GPU_DB,
  MOTHERBOARD_DB,
  PSU_DB,
  RAM_DB,
  SSD_DB,
} from './hardwareDb';
import { REFERENCE_RATES } from '../../shared/referenceRates';
import type {
  PartCategoryKey,
  PartPricingInfo,
  PricingCatalogResponse,
} from '../types/pc';

const PART_GROUPS: Array<{ category: PartCategoryKey; parts: Array<{ id: string }> }> = [
  { category: 'cpu', parts: CPU_DB },
  { category: 'gpu', parts: GPU_DB },
  { category: 'motherboard', parts: MOTHERBOARD_DB },
  { category: 'ram', parts: RAM_DB },
  { category: 'ssd', parts: SSD_DB },
  { category: 'psu', parts: PSU_DB },
  { category: 'pcCase', parts: CASE_DB },
  { category: 'cooler', parts: CPU_COOLER_DB },
];

/**
 * API erişilemediğinde bütçe planlamasını durdurmamak için yerel referans
 * fiyatlarını döndürür. Bunlar canlı mağaza fiyatı değildir.
 */
export function createLocalReferencePricingCatalog(
  reason = 'Canlı fiyat servisine şu anda erişilemiyor.'
): PricingCatalogResponse {
  const partsPricing: Record<string, PartPricingInfo> = {};

  for (const group of PART_GROUPS) {
    for (const part of group.parts) {
      const reference = REFERENCE_RATES[part.id];
      const newPriceTry = reference?.estimatedNewTry ?? null;
      const usedPriceTry = reference?.estimatedUsedTry ?? null;
      const newSourceLabel =
        newPriceTry === null
          ? 'Fiyat verisi mevcut değil'
          : newPriceTry === 0
            ? 'Dahili / ek maliyet yok'
            : 'Tahmini referans fiyat — canlı mağaza teklifi değil';
      const usedSourceLabel =
        usedPriceTry === null
          ? 'İkinci el fiyat verisi mevcut değil'
          : usedPriceTry === 0
            ? 'Dahili / ek maliyet yok'
            : 'Tahmini ikinci el referansı — gerçek ilan değil';

      partsPricing[part.id] = {
        partId: part.id,
        newPriceTry,
        usedPriceTry,
        newStats: null,
        usedStats: null,
        newSourceType: newPriceTry === null ? 'unavailable' : 'estimated_reference',
        usedSourceType: usedPriceTry === null ? 'unavailable' : 'estimated_reference',
        newSourceLabel,
        usedSourceLabel,
        lastCheckedAt: null,
        comparison: {
          newPriceTry,
          usedPriceTry,
          differenceTry:
            newPriceTry !== null && usedPriceTry !== null
              ? newPriceTry - usedPriceTry
              : null,
          savingsPercent:
            newPriceTry !== null && usedPriceTry !== null && newPriceTry > 0
              ? Math.round(((newPriceTry - usedPriceTry) / newPriceTry) * 100)
              : null,
          newSourceLabel,
          usedSourceLabel,
          advantageNote: 'Referans değerler yalnızca yaklaşık bütçe planlaması içindir.',
          riskNote: 'Satın almadan önce mağazadaki veya ilandaki güncel fiyatı doğrulayın.',
        },
      };
    }
  }

  return {
    providerStatus: {
      authorizedApiConfigured: false,
      providerMessage: `${reason} Gösterilen referans değerler canlı mağaza fiyatı değildir.`,
      lastSyncedAt: new Date().toISOString(),
    },
    partsPricing,
    listings: [],
  };
}
