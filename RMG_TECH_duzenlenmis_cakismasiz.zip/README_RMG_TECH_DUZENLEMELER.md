# RMG TECH — temizlenmiş proje paketi

Bu paket, yüklenen arşivdeki iki ayrı proje kopyasını tek bir kök proje altında birleştirir.
Google AI Studio'ya aktarılacak ana uygulama bu dizindeki `package.json`, `src/`, `shared/` ve `server/` yapısıdır.
Eski/tekrarlanan `rmg_work/` alt kopyası paketten çıkarılmıştır; aynı dosyaların farklı sürümlerinin karışması önlenmiştir.

## Yapılan düzenlemeler

- Üst arama çubuğundan işlemci veya ekran kartı seçildiğinde PC Toplama akışına geçilir ve seçilen ürünün gerçek katalog kimliği kullanılır.
- İşlemci seçimi, `handleBuildWithCpu` üzerinden yapılarak anakart, RAM ve soğutucu önerileri de işlemci soketine göre güncellenir.
- Yetkili fiyat API'si erişilemezse uygulama artık boş fiyat kataloğuyla kalmaz; ortak referans fiyat dosyasından yerel referans kataloğu oluşturur.
- Ryzen 5 7500F'nin `cpu-r5-7500f` kimliği ile referans fiyat kaydı eşleşir.
- Referans fiyatlar canlı mağaza teklifi gibi sunulmaz. API çalışmıyorsa fiyat kaynağı uyarısı gösterilir; referans değeri olmayan ürünlerde “Fiyat verisi yok” yazılır.
- Referans fiyatların tek kaynak dosyası `shared/referenceRates.ts` olarak düzenlendi; sunucu ve istemci aynı dosyayı kullanır.
- Yinelenen eski proje kopyası çıkarıldı.

## Önemli fiyat notu

Bu paketteki referans fiyatlar gerçek zamanlı mağaza fiyatı değildir ve güncel piyasa fiyatı garantisi vermez. Gerçek mağaza karşılaştırması için mağazalardan alınmış yetkili API/XML/ürün feed bağlantısı gerekir. Böyle bir bağlantı yapılandırılmadıkça uygulama fiyatları “tahmini referans” olarak etiketler.

## Çalıştırma

- `npm install`
- `npm run dev`

`.env.example` içindeki `PRICE_API_BASE_URL` ve `PRICE_API_KEY` yalnızca izinli bir sağlayıcı entegrasyonu varsa doldurulmalıdır.
